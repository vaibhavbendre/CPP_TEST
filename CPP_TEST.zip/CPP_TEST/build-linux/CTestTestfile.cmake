# CMake generated Testfile for 
# Source directory: /home/cfd-user/Downloads/CPP_TEST/CPP_TEST_BKP2
# Build directory: /home/cfd-user/Downloads/CPP_TEST/CPP_TEST_BKP2/build-linux
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(cinema_tests "/home/cfd-user/Downloads/CPP_TEST/CPP_TEST_BKP2/build-linux/cinema_tests")
set_tests_properties(cinema_tests PROPERTIES  _BACKTRACE_TRIPLES "/home/cfd-user/Downloads/CPP_TEST/CPP_TEST_BKP2/CMakeLists.txt;48;add_test;/home/cfd-user/Downloads/CPP_TEST/CPP_TEST_BKP2/CMakeLists.txt;0;")
