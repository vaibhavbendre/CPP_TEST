file(REMOVE_RECURSE
  "libcinema.a"
)
