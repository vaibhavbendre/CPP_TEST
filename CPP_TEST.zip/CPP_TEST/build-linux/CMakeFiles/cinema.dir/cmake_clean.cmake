file(REMOVE_RECURSE
  "CMakeFiles/cinema.dir/src/booking_service.cpp.o"
  "CMakeFiles/cinema.dir/src/cli.cpp.o"
  "CMakeFiles/cinema.dir/src/seat.cpp.o"
  "libcinema.a"
  "libcinema.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/cinema.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
