file(REMOVE_RECURSE
  "CMakeFiles/cinema_cli.dir/app/main.cpp.o"
  "cinema_cli"
  "cinema_cli.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/cinema_cli.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
