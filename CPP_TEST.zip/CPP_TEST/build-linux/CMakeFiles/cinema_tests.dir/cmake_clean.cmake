file(REMOVE_RECURSE
  "CMakeFiles/cinema_tests.dir/tests/tests.cpp.o"
  "cinema_tests"
  "cinema_tests.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/cinema_tests.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
